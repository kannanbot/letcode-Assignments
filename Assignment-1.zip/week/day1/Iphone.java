package week.day1;

public class Iphone {


	public void makeCall() {
		
		System.out.println("Make a call asap");
		
		
	}
	
	public void model() {
		
		System.out.println("New model");
		
		
		
	}
	
}
