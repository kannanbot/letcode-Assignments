package week1.day1;

public class Class2 {

	public static void main(String[] args) {

		Learnmethod lm1 = new Learnmethod();
		lm1.noofwheels();
		lm1.password();
		lm1.username();
	

		
		
	}

}
