package week1.day1;

public class Car {



	public void driveCar() {
		
		System.out.println("Maintain Speed limit");
		
		
	}
	
	public void applyBrake() {
		
		System.out.println("Hit brakes");
		
		
	}
	
	public void soundHorn() {
		
		System.out.println("Use me");
		
		
	}
	
	public void isPuncture() {
		
		System.out.println("Quick fix");
		
		
		
		
	}
	
	public static void main(String[] args) {
		
		Car c = new Car();
		
		c.applyBrake();
		c.driveCar();
		c.soundHorn();
		c.isPuncture();

	}
	
	
}
