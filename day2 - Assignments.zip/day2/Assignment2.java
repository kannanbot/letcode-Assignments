package week1.day2;

public class Assignment2 {

	public static void main(String[] args) {
		
		Assignment2 assi = new Assignment2();	
		
		assi.factorial();

	}
	
	
	public void factorial() {
		
		  int i,fact=1;  
		  
		  int number=5;
		  
		  for(i=1;i<=number;i++)
		  {    
		      fact=fact*i;    
		  }    
		  System.out.println("Factorial of "+number+" is: "+fact);    
		 }  
		
		
		
	}
	


