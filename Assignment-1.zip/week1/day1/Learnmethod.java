package week1.day1;

public class Learnmethod {

	public void noofwheels(){
		
		System.out.println("NO of wheels : 4");
		
	}
	
	private void model() {
		
		System.out.println("AUDI");
		
		
	}
		

	protected void password() {
		
		System.out.println("password");
		
	}
	
	void username() {
		
		System.out.println("kannank");
		
	}
	
	public static void main(String[] args) {
		
		Learnmethod lm = new Learnmethod();
		
		lm.noofwheels();
		lm.model();
		lm.password();
		lm.username();
		
		
		
	}
	
	
}


