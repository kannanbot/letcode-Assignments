package week1.day2;

public class Forloop {

	public static void main(String[] args) {

		int num = 0;
		
		for (int i = 10; i >= num; i--) {
			
			System.out.println(i);
			
		}
		
		for (int i = 0; i < args.length; i++) {
			
		}

	}

}
