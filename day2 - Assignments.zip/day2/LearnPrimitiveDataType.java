package week1.day2;

public class LearnPrimitiveDataType {

	public static void main(String[] args) {

		LearnPrimitiveDataType pd = new LearnPrimitiveDataType();
		
		int add = pd.add(1, 2);
		
		System.out.println(add);

	}

	

	public int add (int a,int b) {
		return a+a+b+b;
		
		
		
		
	}
	
	
}

