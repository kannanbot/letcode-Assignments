package week.day1;

public class SmartPhone {

	public static void main(String[] args) {
		
		Iphone ip = new Iphone();
		
		ip.makeCall();
		ip.model();

	}

}
