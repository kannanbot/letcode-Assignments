package week1.day2;

public class Assignment1 {

	public static void main(String[] args) {
		
		Assignment1 as = new Assignment1();
		
		as.Pseudocode();
		

	}
	
	
	public void Pseudocode() {
		
		int number = -50;
		
		if (number<0) {
			
            System.out.println(number +" "+ "is a negative number");             			
			
			int number1 = number * - 1; 
			
			System.out.println(number1 +" "+   "this is converted number");
		}
		
		
		
		
		
	}

}
